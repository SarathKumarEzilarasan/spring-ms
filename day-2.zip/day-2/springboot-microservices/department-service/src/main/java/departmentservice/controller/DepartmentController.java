package departmentservice.controller;

import departmentservice.dto.DepartmentDto;
import departmentservice.service.DepartmentService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/departments")
@AllArgsConstructor
public class DepartmentController {
    private DepartmentService departmentService;

    @PostMapping
    public ResponseEntity<DepartmentDto> saveDepartment(@RequestBody DepartmentDto departmentDto){
       DepartmentDto dto = departmentService.saveDepartment(departmentDto);
       return new ResponseEntity<>(dto, HttpStatus.CREATED);
    }

    @GetMapping("{department-code}")
    public ResponseEntity<DepartmentDto> getDepartment(@PathVariable("department-code") String departmentCode){
       DepartmentDto dto = departmentService.getDepartmentByCode(departmentCode);
       return new ResponseEntity<>(dto, HttpStatus.OK);
    }
}
