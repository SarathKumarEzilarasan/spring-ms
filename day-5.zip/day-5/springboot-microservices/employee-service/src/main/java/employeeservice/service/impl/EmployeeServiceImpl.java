package employeeservice.service.impl;

import employeeservice.dto.ApiResponseDto;
import employeeservice.dto.DepartmentDto;
import employeeservice.dto.EmployeeDto;
import employeeservice.entity.Employee;
import employeeservice.mapper.EmployeeMapper;
import employeeservice.repository.EmployeeRepository;
import employeeservice.service.APIClient;
import employeeservice.service.EmployeeService;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@AllArgsConstructor
public class EmployeeServiceImpl implements EmployeeService {

    private EmployeeRepository employeeRepository;
    //    private RestTemplate restTemplate;
//    private WebClient webClient;
    private APIClient apiClient;

    @Override
    public EmployeeDto saveEmployee(EmployeeDto employeeDto) {

        Employee employee = EmployeeMapper.mapToEmployee(employeeDto);
        Employee savedEmployee = employeeRepository.save(employee);

        return EmployeeMapper.mapToEmployeeDto(savedEmployee);
    }

    @CircuitBreaker(name = "{spring.application.name}",
            fallbackMethod = "getDefaultDepartment")
    @Retry(name = "{spring.application.name}")
    @Override
    public ApiResponseDto getEmployeeById(Long id) {
        Employee savedEmployee = employeeRepository.getReferenceById(id);
        EmployeeDto employeeDto = EmployeeMapper.mapToEmployeeDto(savedEmployee);

//        ResponseEntity<DepartmentDto> responseEntity = restTemplate
//                .getForEntity("http://localhost:8080/api/departments/" + employeeDto.getDepartmentCode()
//                        , DepartmentDto.class);
//        DepartmentDto departmentDto = responseEntity.getBody();

//        DepartmentDto departmentDto = webClient.get()
//                .uri("http://localhost:8080/api/departments/" + employeeDto.getDepartmentCode())
//                .retrieve()
//                .bodyToMono(DepartmentDto.class).block();

        DepartmentDto departmentDto = apiClient.getDepartment(employeeDto.getDepartmentCode());

        ApiResponseDto apiResponseDto = new ApiResponseDto();
        apiResponseDto.setEmployeeDto(employeeDto);
        apiResponseDto.setDepartmentDto(departmentDto);

        return apiResponseDto;
    }


    public ApiResponseDto getDefaultDepartment(Long id, Exception exception) {
        System.out.println("inside default department method");
        Employee savedEmployee = employeeRepository.getReferenceById(id);
        EmployeeDto employeeDto = EmployeeMapper.mapToEmployeeDto(savedEmployee);
        DepartmentDto departmentDto = new DepartmentDto(1l, "CS",
                "From Default Department Method", "cs-001");

        ApiResponseDto apiResponseDto = new ApiResponseDto();
        apiResponseDto.setEmployeeDto(employeeDto);
        apiResponseDto.setDepartmentDto(departmentDto);

        return apiResponseDto;


    }
}
