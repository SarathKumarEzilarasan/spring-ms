package employeeservice.service.impl;

import employeeservice.dto.ApiResponseDto;
import employeeservice.dto.DepartmentDto;
import employeeservice.dto.EmployeeDto;
import employeeservice.entity.Employee;
import employeeservice.mapper.EmployeeMapper;
import employeeservice.repository.EmployeeRepository;
import employeeservice.service.APIClient;
import employeeservice.service.EmployeeService;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@AllArgsConstructor
public class EmployeeServiceImpl implements EmployeeService {

    private EmployeeRepository employeeRepository;
    //    private RestTemplate restTemplate;
//    private WebClient webClient;
    private APIClient apiClient;

    @Override
    public EmployeeDto saveEmployee(EmployeeDto employeeDto) {

        Employee employee = EmployeeMapper.mapToEmployee(employeeDto);
        Employee savedEmployee = employeeRepository.save(employee);

        return EmployeeMapper.mapToEmployeeDto(savedEmployee);
    }

    @Override
    public ApiResponseDto getEmployeeById(Long id) {
        Employee savedEmployee = employeeRepository.getReferenceById(id);
        EmployeeDto employeeDto = EmployeeMapper.mapToEmployeeDto(savedEmployee);

//        ResponseEntity<DepartmentDto> responseEntity = restTemplate
//                .getForEntity("http://localhost:8080/api/departments/" + employeeDto.getDepartmentCode()
//                        , DepartmentDto.class);
//        DepartmentDto departmentDto = responseEntity.getBody();

//        DepartmentDto departmentDto = webClient.get()
//                .uri("http://localhost:8080/api/departments/" + employeeDto.getDepartmentCode())
//                .retrieve()
//                .bodyToMono(DepartmentDto.class).block();

        DepartmentDto departmentDto = apiClient.getDepartment(employeeDto.getDepartmentCode());

        ApiResponseDto apiResponseDto = new ApiResponseDto();
        apiResponseDto.setEmployeeDto(employeeDto);
        apiResponseDto.setDepartmentDto(departmentDto);

        return apiResponseDto;
    }
}
